from rest_framework.test import APITestCase,APIClient
from rest_framework import status
from rest_framework.exceptions import ValidationError
from .models import Panel, OneHourElectricity
from django.db.utils import IntegrityError
from .serializers import PanelSerializer, OneHourElectricitySerializer
from .views import PanelViewSet, HourAnalyticsView, DayAnalyticsView


# TODO Test cases
#  10)


class PanelTestCase(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.view = PanelViewSet.as_view({'get': 'list'})
        self.uri = '/panel/'
        Panel.objects.create(brand="Areva", serial="AAAA1111BBBB2222", latitude=12.345678, longitude=98.765543)


    def test_panel_listing(self):
        response = self.client.get(self.uri, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)

    def test_panel_get(self):
        response = self.client.get(self.uri+'1/', format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual([response.data["serial"], response.data["brand"],
                          response.data["latitude"], response.data["longitude"]],
                         ["AAAA1111BBBB2222", "Areva", "12.345678", "98.765543"])


    def test_panel_partial_update_fail(self):
        """ Patching is not allowed hence testing the update fail confirmation """

        params = {
            "id" : 1,
            "brand": "BMW",
            "serial": "DMWHHBBJJDDTTM11",
            "latitude": 19.689385,
            "longitude": 148.356699
        }
        response = self.client.patch(self.uri, params)
        self.assertEqual(response.status_code, 405,
                         'Expected Response Code 405, received {0} instead.'
                         .format(response.status_code))

    def test_panel_post_fail(self):
        """ Post fails with wrong data, testing the post fail confirmation"""
        params = {
            "brand": "BMW",
            "serial": "WHHBBJJDDTTM11",
            "latitude": 19.689385,
            "longitude": 148.356699
        }
        response = self.client.post(self.uri, params)
        self.assertEqual(response.status_code, 400,
                         'Expected Response Code 400, received {0} instead.'
                         .format(response.status_code))


    def test_panel_put(self):
        params = {
            "id" : 1,
            "brand": "BMW",
            "serial": "BMWHHBBJJDDTTM11",
            "latitude": 19.689385,
            "longitude": 1.356699
        }
        response = self.client.put(self.uri+'1/', params)
        self.assertEqual(response.status_code, 200,
                         'Expected Response Code 200, received {0} instead.'
                         .format(response.status_code))

    def test_panel_brand_serial_unique(self):
        with self.assertRaises(Exception) as raised:
            Panel.objects.create(brand="Areva", serial="AAAA1111BBBB2222", latitude=12.345678, longitude=98.765543)
        self.assertEqual(IntegrityError, type(raised.exception))

    def test_panel_validate_serial_multiple(self):
        """
        I had to use this method as paramterized decorator
         of pytest does not work with functions under a class

        Check - length greater than 16 and length less than 16 for serial
         """
        test_expected = {}
        test_raised_exception = {}
        serial_values = [[1, "AAAA1111BBBB22222", ValidationError], [2, "AAAA1111BBBB22222", ValidationError]]

        def panel_validate_serial(value):
            with self.assertRaises(Exception) as raised:
                PanelSerializer.validate_serial(PanelSerializer, value)
            return type(raised.exception)

        for key_value, value, expected in serial_values:
            test_raised_exception.update({key_value: panel_validate_serial(value)})
            test_expected.update({key_value: expected})

        self.assertDictEqual(test_expected, test_raised_exception)

    def test_panel_validate_latitude_multiple(self):
        """
        I had to use this method as paramterized decorator
         of pytest does not work with functions under a class

        Check -
        latitude is between 90 to - 90 assertion of failure if more than 90
        latitude is between 90 to - 90 assertion of failure if less than - 90
        latitude decimal values length more than 6 assertion is failure


         """
        test_expected = {}
        test_raised_exception = {}
        latitude_values = [[1, 127.368988, ValidationError],
                           [2, -90.01, ValidationError],
                           [3, 45.8988664317, ValidationError]]

        def panel_validate_latitude(value):
            with self.assertRaises(Exception) as raised:
                PanelSerializer.validate_latitude(PanelSerializer, value)
            return type(raised.exception)

        for key_value, value, expected in latitude_values:
            test_raised_exception.update({key_value: panel_validate_latitude(value)})
            test_expected.update({key_value: expected})

        self.assertDictEqual(test_expected, test_raised_exception)

    def test_panel_validate_longitude_multiple(self):
        """
        I had to use this method as paramterized decorator
         of pytest does not work with functions under a class

        Check -
        longitude is between 180 to - 180 assertion of failure if more than 180
        longitude is between 180 to - 180 assertion of failure if less than - 180
        longitude decimal values length more than 6 assertion is failure


         """
        test_expected = {}
        test_raised_exception = {}
        longitude_values = [[1, 197.368988, ValidationError],
                            [2, -180.01, ValidationError],
                            [3, 45.8988664317, ValidationError]]

        def panel_validate_longitude(value):
            with self.assertRaises(Exception) as raised:
                PanelSerializer.validate_latitude(PanelSerializer, value)
            return type(raised.exception)

        for key_value, value, expected in longitude_values:
            test_raised_exception.update({key_value: panel_validate_longitude(value)})
            test_expected.update({key_value: expected})

        self.assertDictEqual(test_expected, test_raised_exception)

    def test_panel_del(self):
        params = {
            "id": 1
        }
        response = self.client.delete(self.uri+'1/', params)
        self.assertEqual(response.status_code, 204,
                         'Expected Response Code 204, received {0} instead.'
                         .format(response.status_code))

    def test_panel_get_invalid_id(self):
        response = self.client.get(self.uri+'10/', format='json')
        self.assertEqual(response.status_code, 404,
                         'Expected Response Code 404, received {0} instead.'
                         .format(response.status_code))

class OneHourTestCase(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.view = HourAnalyticsView.as_view()
        self.uri = '/panel/1/analytics/'
        Panel.objects.create(brand="BMW", serial="AAAA1111BBBB2222", latitude=12.345678, longitude=98.765543)
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.2, date_time="2018-10-24T07:00:00Z")
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.4, date_time="2018-10-24T08:00:00Z")
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.6, date_time="2018-10-24T09:00:00Z")

    def test_OneHourElectricity_listing(self):
        response = self.client.get(self.uri, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 3)

    def test_HourAnalyticsView_post(self):
        params = {
            "panel": 1,
            "kilo_watt": 1.2,
            "date_time": "2018-12-01T09:00:00Z"
        }
        response = self.client.post(self.uri, params, format='json')
        self.assertEqual(response.status_code, 201,
                         'Expected Response Code 201, received {0} instead.'
                         .format(response.status_code))

    def test_OneHourElectricity_panel_date_time_unique(self):
        with self.assertRaises(Exception) as raised:
            OneHourElectricity.objects.create(panel_id=1, date_time="2018-10-24T09:00:00Z")
        self.assertEqual(IntegrityError, type(raised.exception))

    def test_OneHourElectricitySerializer_validate_kilo_watt(self):
        with self.assertRaises(Exception) as raised:
            OneHourElectricitySerializer.validate_kilo_watt(OneHourElectricitySerializer, -0.01)
        self.assertEqual(ValidationError, type(raised.exception))

    def test_OneHourElectricitySerializer_validate_date_time_(self):
        """
                I had to use this method as paramterized decorator
                 of pytest does not work with functions under a class

                Check -
                Date time values are hourly and not in additional minutes
                Date time values are hourly and not in additional seconds
                 """
        test_expected = {}
        test_raised_exception = {}
        date_time_values = [[1, "2018-10-24T11:01:00Z", ValidationError],
                            [2, "2018-10-24T11:00:01Z", ValidationError],
                            [3, "2025-10-24T11:00:01Z", ValidationError]]

        def onehourelectricity_validate_serial(value):
            with self.assertRaises(Exception) as raised:
                OneHourElectricitySerializer.validate_date_time(OneHourElectricitySerializer, value)
            return type(raised.exception)

        for key_value, value, expected in date_time_values:
            test_raised_exception.update({key_value: onehourelectricity_validate_serial(value)})
            test_expected.update({key_value: expected})

        self.assertDictEqual(test_expected, test_raised_exception)

    def test_OneHourElectricity_del_fail(self):
        """ delete method is not allowed hence testing the confirmation"""
        params = {
            "id": 1
        }
        response = self.client.delete(self.uri, params)
        self.assertEqual(response.status_code, 405,
                         'Expected Response Code 405, received {0} instead.'
                         .format(response.status_code))


class OneHourDayTestCase(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.view = DayAnalyticsView.as_view()
        self.uri = '/panel/1/analytics/day/'
        Panel.objects.create(brand="Areva", serial="AAAA1111BBBB2222", latitude=12.345678, longitude=98.765543)
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.2, date_time="2018-10-24T07:00:00Z")
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.4, date_time="2018-10-24T08:00:00Z")
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.6, date_time="2018-10-24T09:00:00Z")

        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.2, date_time="2018-10-20T07:00:00Z")
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.4, date_time="2018-10-20T08:00:00Z")
        OneHourElectricity.objects.create(panel_id=1, kilo_watt=1.6, date_time="2018-10-20T09:00:00Z")

    def test_OneHourDayElectricity_listing(self):
        response = self.client.get(self.uri, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)





